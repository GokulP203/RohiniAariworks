-- Run once in Supabase > SQL Editor
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_id text unique not null,
  idem_key text unique not null,
  created_at timestamptz default now(),
  status text default 'Order Received',
  notes text default '',
  full_name text, mobile text, whatsapp text, email text,
  order_type text, pieces text, blouse_size text, preferred_design text, preferred_colour text,
  event_date text, delivery_date text, budget text,
  description text, address text, instructions text,
  images jsonb default '[]'::jsonb,
  email_sent boolean default false
);
create table if not exists enquiries (
  id uuid primary key default gen_random_uuid(),
  idem_key text unique not null,
  created_at timestamptz default now(),
  notes text default '',
  full_name text, mobile text, email text, work_type text,
  event_date text, budget text, description text,
  images jsonb default '[]'::jsonb,
  email_sent boolean default false
);
-- Lock tables: only the server (service_role key) can read/write. No public access.
alter table orders enable row level security;
alter table enquiries enable row level security;
-- Private bucket for reference images
insert into storage.buckets (id, name, public) values ('references', 'references', false) on conflict (id) do nothing;
