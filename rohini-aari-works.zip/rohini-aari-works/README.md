# Rohini Aari Works - Website

Static site + Vercel serverless API (`/api`). No build step, no npm packages.

## Deploy (GitHub -> Vercel)
1. Create a GitHub repo, upload ALL files from this folder (the folder contents, not the folder itself) so `index.html` and `api/` are at the repo root.
2. Supabase (free): new project -> SQL Editor -> paste `supabase.sql` -> Run. Then Settings -> API: copy **Project URL** and **service_role** key.
3. Resend (free): sign up using **g03128519@gmail.com**, create an API key. (Without a verified domain, Resend only delivers to the e-mail you signed up with.)
4. Vercel -> Add New Project -> import the GitHub repo -> Framework: **Other** -> add the variables from `.env.example` -> Deploy.
5. Open `https://YOUR-SITE.vercel.app/api/health`. It must show database/email/admin = true.
6. Replace `YOUR-DOMAIN.vercel.app` in `sitemap.xml` and `robots.txt` with your real domain.

## Before going live
- Put your real work photos in `images/` (see names in `assets/config.js`; also `hero.jpg`, `about.jpg`). Missing photos show an elegant placeholder.
- Set `mapQuery` in `assets/config.js` to the shop address.
- Notification e-mail: the brief says both `gmail.cm` and `gmail.com`. `gmail.cm` is not a Gmail address, so `.env.example` uses `gmail.com`. Change `NOTIFY_EMAIL` if you really want something else.
- Admin: `/admin`, login with `ADMIN_USER` / `ADMIN_PASSWORD` from Vercel variables.

## Testing status
Code syntax checked, and the API logic was run against simulated database/email responses. Not yet tested against a live Supabase/Resend/Vercel account: do one enquiry and one order after deploying and check the e-mail and /admin.
