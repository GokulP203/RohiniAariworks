const L = require('./_lib');
const clean = (v, max = 1000) => String(v == null ? '' : v).trim().slice(0, max);
const phone = (v) => { const d = String(v || '').replace(/\D/g, '').replace(/^91(?=\d{10}$)/, ''); return /^[6-9]\d{9}$/.test(d) ? d : ''; };
const date = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(v || '') ? v : '');
const validMail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
const ORDER_TYPES = ['Bridal Aari Work', 'Bridal Blouse Maggam Work', 'Wedding Blouse', 'Reception Blouse', 'Engagement Blouse', 'Simple Aari Work', 'Kids Aari Work', 'Custom Aari Design', 'Other'];
const WORK_TYPES = ['Bridal Aari Blouse', 'Maggam Work', 'Bridal Wedding Collection', 'Peacock Design', 'Floral Aari Design', 'Temple Jewellery Design', 'Zardosi Work', 'Designer Blouse', 'Traditional Aari Embroidery', 'Custom Design'];
const FIELDS = {
  order: [['order_id', 'Order ID'], ['full_name', 'Customer'], ['mobile', 'Mobile'], ['whatsapp', 'WhatsApp (info only)'], ['email', 'Email'], ['order_type', 'Order type'], ['pieces', 'Pieces'], ['blouse_size', 'Blouse size'], ['preferred_design', 'Preferred design'], ['preferred_colour', 'Preferred colour'], ['event_date', 'Event date'], ['delivery_date', 'Expected delivery'], ['budget', 'Budget'], ['description', 'Work description'], ['address', 'Delivery address'], ['instructions', 'Additional instructions']],
  enquiry: [['full_name', 'Customer'], ['mobile', 'Mobile'], ['email', 'Email'], ['work_type', 'Work type'], ['event_date', 'Event date'], ['budget', 'Budget'], ['description', 'Design description']],
};

module.exports = async function (kind, req, res) {
  try {
    if (req.method !== 'POST') return L.send(res, 405, { error: 'Method not allowed' });
    const b = req.body || {};
    if (b.website) return L.send(res, 400, { error: 'Invalid submission' });
    const idem = clean(b.idem_key, 64).replace(/[^a-zA-Z0-9-]/g, '');
    if (idem.length < 8) return L.send(res, 400, { error: 'Please refresh the page and try again.' });
    const isOrder = kind === 'order', table = isOrder ? 'orders' : 'enquiries';
    const f = isOrder
      ? { full_name: clean(b.full_name, 100), mobile: phone(b.mobile), whatsapp: clean(b.whatsapp, 20), email: clean(b.email, 120), order_type: clean(b.order_type, 60), pieces: clean(b.pieces, 10), blouse_size: clean(b.blouse_size, 40), preferred_design: clean(b.preferred_design, 200), preferred_colour: clean(b.preferred_colour, 100), event_date: date(b.event_date), delivery_date: date(b.delivery_date), budget: clean(b.budget, 60), description: clean(b.description, 3000), address: clean(b.address, 500), instructions: clean(b.instructions, 1500) }
      : { full_name: clean(b.full_name, 100), mobile: phone(b.mobile), email: clean(b.email, 120), work_type: clean(b.work_type, 60), event_date: date(b.event_date), budget: clean(b.budget, 60), description: clean(b.description, 3000) };
    if (f.full_name.length < 2) return L.send(res, 400, { error: 'Please enter your name.' });
    if (!f.mobile) return L.send(res, 400, { error: 'Please enter a valid 10-digit mobile number.' });
    if ((!isOrder || f.email) && !validMail(f.email)) return L.send(res, 400, { error: 'Please enter a valid email address.' });
    if (isOrder && !ORDER_TYPES.includes(f.order_type)) return L.send(res, 400, { error: 'Please choose an order type.' });
    if (!isOrder && !WORK_TYPES.includes(f.work_type)) return L.send(res, 400, { error: 'Please choose the Aari work type.' });
    if (!isOrder && (!f.event_date || !f.budget)) return L.send(res, 400, { error: 'Please fill the event date and budget range.' });
    if (f.description.length < 10) return L.send(res, 400, { error: 'Please describe the design in a few words.' });

    let row = await L.getBy(table, 'idem_key', idem);
    if (row && row.email_sent) return L.send(res, 200, { ok: true, order_id: row.order_id || null });
    if (!row) {
      const images = await L.uploadImages(b.images, table + '/' + idem);
      for (let i = 0; i < 4 && !row; i++) {
        const rec = { ...f, images, idem_key: idem };
        if (isOrder) rec.order_id = L.newOrderId();
        const r = await L.insertRow(table, rec);
        if (r.row) row = r.row;
        else if (!isOrder || !/order_id/.test(r.conflict)) { row = await L.getBy(table, 'idem_key', idem); if (!row) throw new Error('Could not save'); }
      }
      if (!row) throw new Error('Could not generate a unique Order ID');
    }
    try {
      const links = (await Promise.all((row.images || []).map(L.signUrl))).filter(Boolean);
      const rows = FIELDS[kind].map(([k, l]) => `<tr><td style="padding:6px 12px;color:#8a5a64"><b>${l}</b></td><td style="padding:6px 12px">${L.esc(row[k] || '-').replace(/\n/g, '<br>')}</td></tr>`).join('');
      const imgs = links.length ? links.map((u, i) => `<a href="${L.esc(u)}">Reference image ${i + 1}</a>`).join('<br>') : 'None uploaded';
      const html = `<div style="font-family:Arial,sans-serif"><h2>${isOrder ? 'New Order ' + L.esc(row.order_id) : 'New Enquiry'} - Rohini Aari Works</h2><table>${rows}</table><p style="padding:6px 12px"><b>Reference images (links valid 7 days):</b><br>${imgs}</p></div>`;
      await L.sendMail({ subject: isOrder ? `New Order ${row.order_id} - ${row.full_name}` : `New Enquiry - ${row.full_name}`, html, replyTo: validMail(row.email) ? row.email : undefined });
      await L.patch(table, row.id, { email_sent: true });
    } catch (e) {
      console.error(e);
      return L.send(res, 502, { error: `Your ${isOrder ? 'order' : 'enquiry'} was saved${isOrder ? ' (Order ID ' + row.order_id + ')' : ''}, but the notification email failed. Please press the button again or call 9944789856.`, order_id: row.order_id || null });
    }
    return L.send(res, 200, { ok: true, order_id: row.order_id || null });
  } catch (e) {
    console.error(e);
    return L.send(res, e.status || 500, { error: e.status ? e.message : 'Something went wrong on our side and nothing was submitted. Please try again or call 9944789856.' });
  }
};
