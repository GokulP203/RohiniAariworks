const L = require('../_lib');
module.exports = async (req, res) => {
  try {
    if (!L.requireAdmin(req, res)) return;
    const type = req.query.type === 'enquiries' ? 'enquiries' : 'orders';
    let url = `/rest/v1/${type}?select=*&order=created_at.desc&limit=100`;
    const q = encodeURIComponent(String(req.query.q || '').replace(/[^a-zA-Z0-9\- ]/g, '').trim());
    if (q) url += `&or=(${type === 'orders' ? 'order_id.ilike.*' + q + '*,' : ''}mobile.ilike.*${q}*,full_name.ilike.*${q}*)`;
    const st = String(req.query.status || '');
    if (type === 'orders' && L.STATUSES.includes(st)) url += '&status=eq.' + encodeURIComponent(st);
    const r = await L.sb(url);
    if (!r.ok) throw new Error(await r.text());
    const rows = await r.json();
    await Promise.all(rows.map(async (x) => { x.image_urls = (await Promise.all((x.images || []).map(L.signUrl))).filter(Boolean); }));
    let stats = null;
    if (type === 'orders') {
      const a = await (await L.sb('/rest/v1/orders?select=status')).json();
      stats = { total: a.length, pending: a.filter((o) => !['Delivered', 'Cancelled'].includes(o.status)).length };
    }
    L.send(res, 200, { rows, stats });
  } catch (e) { console.error(e); L.send(res, 500, { error: 'Could not load data' }); }
};
