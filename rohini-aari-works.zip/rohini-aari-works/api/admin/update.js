const L = require('../_lib');
module.exports = async (req, res) => {
  try {
    if (req.method !== 'POST') return L.send(res, 405, { error: 'Method not allowed' });
    if (!L.requireAdmin(req, res)) return;
    const { type, id, status, notes } = req.body || {};
    const table = type === 'enquiries' ? 'enquiries' : 'orders';
    if (!/^[0-9a-f-]{36}$/.test(id || '')) return L.send(res, 400, { error: 'Bad id' });
    const data = { notes: String(notes || '').slice(0, 3000) };
    if (table === 'orders') { if (!L.STATUSES.includes(status)) return L.send(res, 400, { error: 'Bad status' }); data.status = status; }
    await L.patch(table, id, data);
    L.send(res, 200, { ok: true });
  } catch (e) { console.error(e); L.send(res, 500, { error: 'Update failed' }); }
};
