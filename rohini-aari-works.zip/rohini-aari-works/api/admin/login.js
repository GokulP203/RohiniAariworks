const L = require('../_lib');
module.exports = async (req, res) => {
  if (req.method !== 'POST') return L.send(res, 405, { error: 'Method not allowed' });
  if (!L.E('ADMIN_USER') || !L.E('ADMIN_PASSWORD') || L.E('SESSION_SECRET').length < 16) return L.send(res, 500, { error: 'Admin login is not configured on the server.' });
  const { username, password } = req.body || {};
  if (!(L.safeEq(username, L.E('ADMIN_USER')) & L.safeEq(password, L.E('ADMIN_PASSWORD')))) {
    await new Promise((r) => setTimeout(r, 800));
    return L.send(res, 401, { error: 'Wrong username or password' });
  }
  L.send(res, 200, { token: L.makeToken() });
};
