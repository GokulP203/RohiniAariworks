module.exports = (req, res) => require('./_submit')('enquiry', req, res);
