module.exports = (req, res) => require('./_submit')('order', req, res);
