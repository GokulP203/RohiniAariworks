const crypto = require('crypto');
const E = (k) => process.env[k] || '';
const send = (res, code, body) => res.status(code).json(body);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const STATUSES = ['Order Received', 'Order Confirmed', 'Advance Payment Received', 'Work in Progress', 'Work Completed', 'Ready for Delivery', 'Delivered', 'Cancelled'];
const base = () => E('SUPABASE_URL').replace(/\/$/, '');

function sb(path, opts = {}) {
  if (!base() || !E('SUPABASE_SERVICE_KEY')) throw new Error('Database not configured (SUPABASE_URL / SUPABASE_SERVICE_KEY missing)');
  const key = E('SUPABASE_SERVICE_KEY');
  return fetch(base() + path, { ...opts, headers: { apikey: key, Authorization: 'Bearer ' + key, 'Content-Type': 'application/json', ...(opts.headers || {}) } });
}
async function insertRow(table, row) {
  const r = await sb('/rest/v1/' + table, { method: 'POST', headers: { Prefer: 'return=representation' }, body: JSON.stringify(row) });
  const t = await r.text();
  if (r.ok) return { row: JSON.parse(t)[0] };
  if (r.status === 409) return { conflict: t };
  throw new Error('DB insert failed: ' + t);
}
async function getBy(table, col, val) {
  const r = await sb(`/rest/v1/${table}?${col}=eq.${encodeURIComponent(val)}&select=*`);
  if (!r.ok) throw new Error('DB read failed: ' + (await r.text()));
  return (await r.json())[0];
}
async function patch(table, id, data) {
  const r = await sb(`/rest/v1/${table}?id=eq.${id}`, { method: 'PATCH', body: JSON.stringify(data) });
  if (!r.ok) throw new Error('DB update failed: ' + (await r.text()));
}
async function uploadImages(list, folder) {
  const paths = [];
  for (const d of (Array.isArray(list) ? list : []).slice(0, 4)) {
    const m = /^data:(image\/(jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(d || '');
    if (!m) throw Object.assign(new Error('Only JPG, PNG or WEBP images are allowed.'), { status: 400 });
    const buf = Buffer.from(m[3], 'base64');
    if (buf.length > 2 * 1024 * 1024) throw Object.assign(new Error('Each image must be under 2 MB.'), { status: 400 });
    const p = `${folder}/${crypto.randomUUID()}.${m[2] === 'jpeg' ? 'jpg' : m[2]}`;
    const r = await sb('/storage/v1/object/references/' + p, { method: 'POST', headers: { 'Content-Type': m[1] }, body: buf });
    if (!r.ok) throw new Error('Image upload failed: ' + (await r.text()));
    paths.push(p);
  }
  return paths;
}
async function signUrl(p) {
  const r = await sb('/storage/v1/object/sign/references/' + p, { method: 'POST', body: JSON.stringify({ expiresIn: 604800 }) });
  if (!r.ok) return null;
  const j = await r.json();
  return base() + '/storage/v1' + j.signedURL;
}
async function sendMail({ subject, html, replyTo }) {
  const to = E('NOTIFY_EMAIL');
  if (!E('RESEND_API_KEY') || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to)) throw new Error('Email not configured (RESEND_API_KEY / NOTIFY_EMAIL)');
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + E('RESEND_API_KEY'), 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: E('MAIL_FROM') || 'Rohini Aari Works <onboarding@resend.dev>', to: [to], subject, html, reply_to: replyTo || undefined }),
  });
  if (!r.ok) throw new Error('Email failed: ' + (await r.text()));
}
const b64 = (s) => Buffer.from(s).toString('base64url');
const sig = (p) => crypto.createHmac('sha256', E('SESSION_SECRET')).update(p).digest('base64url');
const makeToken = () => { const p = b64(JSON.stringify({ role: 'admin', exp: Date.now() + 8 * 3600e3 })); return p + '.' + sig(p); };
function requireAdmin(req, res) {
  const [p, s] = (req.headers.authorization || '').replace(/^Bearer /, '').split('.');
  if (p && s && E('SESSION_SECRET').length >= 16) {
    const ok = sig(p);
    if (s.length === ok.length && crypto.timingSafeEqual(Buffer.from(s), Buffer.from(ok))) {
      try { const d = JSON.parse(Buffer.from(p, 'base64url')); if (d.role === 'admin' && d.exp > Date.now()) return true; } catch (e) {}
    }
  }
  send(res, 401, { error: 'Not authorised' });
  return false;
}
const safeEq = (a, b) => crypto.timingSafeEqual(crypto.createHash('sha256').update(String(a)).digest(), crypto.createHash('sha256').update(String(b)).digest());
const newOrderId = () => {
  const d = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const A = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  return 'RAW-' + d + '-' + Array.from(crypto.randomBytes(4), (x) => A[x % A.length]).join('');
};
module.exports = { E, send, esc, STATUSES, sb, insertRow, getBy, patch, uploadImages, signUrl, sendMail, makeToken, requireAdmin, safeEq, newOrderId };
