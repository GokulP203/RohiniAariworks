const L = require('./_lib');
module.exports = (req, res) => L.send(res, 200, { ok: true, configured: { database: !!(L.E('SUPABASE_URL') && L.E('SUPABASE_SERVICE_KEY')), email: !!(L.E('RESEND_API_KEY') && L.E('NOTIFY_EMAIL')), admin: !!(L.E('ADMIN_USER') && L.E('ADMIN_PASSWORD') && L.E('SESSION_SECRET').length >= 16) } });
