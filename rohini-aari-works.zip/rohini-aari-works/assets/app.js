(function(){
const $=(s,r=document)=>r.querySelector(s),S=window.SITE;
// mandala motif
const m=$('#mg');if(m){let h='';for(let i=0;i<24;i++)h+=`<path d="M0 -22 C 12 -45 12 -75 0 -96 C -12 -75 -12 -45 0 -22Z" transform="rotate(${i*15})" opacity="${i%2?.55:1}"/>`;
for(let i=0;i<12;i++)h+=`<path d="M0 -8 C 7 -20 7 -34 0 -44 C -7 -34 -7 -20 0 -8Z" transform="rotate(${i*30})" stroke="#B76E79"/>`;
h+='<circle r="100" stroke-dasharray="1 4"/><circle r="4" fill="#C9A96E"/>';m.innerHTML=h}
// nav
const bg=$('.burger'),nv=$('.nav nav');if(bg)bg.onclick=()=>nv.classList.toggle('open');nv&&nv.addEventListener('click',e=>{if(e.target.tagName==='A')nv.classList.remove('open')});
// contact links
document.querySelectorAll('[data-phone]').forEach(a=>{a.href='tel:+91'+S.phone;a.textContent=a.dataset.phone||S.phone});
document.querySelectorAll('[data-mail]').forEach(a=>{a.href='mailto:'+S.email;a.textContent=a.dataset.mail||S.email});
const mp=$('#map');if(mp)mp.src='https://www.google.com/maps?q='+encodeURIComponent(S.mapQuery)+'&output=embed';
const ml=$('#maplink');if(ml)ml.href='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(S.mapQuery);
// gallery
const gr=$('#grid');if(gr){const cats=['All',...window.GALLERY.map(g=>g.cat)];const fl=$('#filters');
fl.innerHTML=cats.map((c,i)=>`<button class="${i?'':'on'}">${c}</button>`).join('');
const draw=c=>{gr.innerHTML='';window.GALLERY.filter(g=>c==='All'||g.cat===c).forEach(g=>{const t=document.createElement('div');t.className='tile';t.tabIndex=0;
const im=new Image();im.loading='lazy';im.alt=g.alt;im.src=g.src;im.onerror=()=>{const p=document.createElement('div');p.className='ph';p.textContent=g.cat;im.replaceWith(p);t.dataset.ph=1};t.append(im);
const sp=document.createElement('span');sp.textContent=g.cat;t.append(sp);
const open=()=>{if(t.dataset.ph)return;$('#lbimg').src=g.src;$('#lbimg').alt=g.alt;$('#lbcap').textContent=g.cat;$('#lb').showModal()};t.onclick=open;t.onkeydown=e=>{if(e.key==='Enter')open()};gr.append(t)})};
draw('All');fl.onclick=e=>{if(e.target.tagName!=='BUTTON')return;fl.querySelectorAll('button').forEach(b=>b.classList.remove('on'));e.target.classList.add('on');draw(e.target.textContent)};
$('#lb .x').onclick=()=>$('#lb').close();$('#lb').onclick=e=>{if(e.target.id==='lb')$('#lb').close()}}
// slider
const sl=$('#slider');if(sl){$('#prev').onclick=()=>sl.scrollBy({left:-340,behavior:'smooth'});$('#next').onclick=()=>sl.scrollBy({left:340,behavior:'smooth'})}
// reveal
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll('.rv').forEach(el=>io.observe(el));
// toast
window.toast=(msg,type)=>{const t=$('#toast');t.textContent=msg;t.className='show '+type;clearTimeout(t._t);t._t=setTimeout(()=>t.className='',6000)};
// forms
const shrink=f=>new Promise((ok,no)=>{const r=new FileReader();r.onerror=()=>no(new Error('Could not read '+f.name));r.onload=()=>{const i=new Image();i.onerror=()=>no(new Error(f.name+' is not a valid image'));i.onload=()=>{const s=Math.min(1,1280/Math.max(i.width,i.height)),c=document.createElement('canvas');c.width=Math.round(i.width*s);c.height=Math.round(i.height*s);c.getContext('2d').drawImage(i,0,0,c.width,c.height);ok(c.toDataURL('image/jpeg',.8))};i.src=r.result};r.readAsDataURL(f)});
document.querySelectorAll('form[data-api]').forEach(form=>{
 let key=(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(16).slice(2));
 const btn=form.querySelector('button[type=submit]'),label=btn.textContent;
 form.addEventListener('submit',async e=>{e.preventDefault();if(btn.disabled)return;
  const d=Object.fromEntries(new FormData(form).entries());delete d.files;d.idem_key=key;
  btn.disabled=true;btn.innerHTML='<span class="spin"></span> Sending...';
  try{const fs=[...(form.querySelector('input[type=file]').files||[])];if(fs.length>4)throw new Error('Please upload up to 4 images only.');
   d.images=await Promise.all(fs.map(shrink));
   const r=await fetch(form.dataset.api,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
   let j={};try{j=await r.json()}catch(x){}
   if(!r.ok||!j.ok)throw new Error(j.error||'Could not submit (error '+r.status+'). Please try again or call '+S.phone+'.');
   const ok=form.dataset.api.endsWith('order');
   form.outerHTML=`<div class="box done" style="background:#fff;border-radius:18px;box-shadow:var(--sh)"><h2>${ok?'Thank you! Your order is placed':'Thank you! Enquiry received'}</h2>${ok?'<p>Your Order ID</p><div class="oid"></div><p>Please note this ID. We will call you shortly to confirm.</p>':'<p>We will contact you very soon.</p>'}<a class="btn" href="/">Back to Home</a></div>`;
   if(ok)document.querySelector('.oid').textContent=j.order_id;window.scrollTo({top:0,behavior:'smooth'});
  }catch(err){toast(err.message,'err');btn.disabled=false;btn.textContent=label}
 })});
})();
