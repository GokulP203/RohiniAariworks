window.SITE = {
  phone: '9944789856',
  email: 'prakashrohini89@gmail.com',
  // Change this to the real shop address / area so the map points to the correct place
  mapQuery: 'Rohini Aari Works',
};
// Gallery: put your own photos in the /images folder and edit the file names here.
window.GALLERY = [
  { cat: 'Bridal Aari Blouse Designs', src: 'images/bridal-aari-1.jpg', alt: 'Bridal Aari embroidery blouse design' },
  { cat: 'Maggam Work Designs', src: 'images/maggam-1.jpg', alt: 'Maggam work blouse design' },
  { cat: 'Bridal Wedding Collections', src: 'images/wedding-1.jpg', alt: 'Bridal wedding blouse collection' },
  { cat: 'Peacock Designs', src: 'images/peacock-1.jpg', alt: 'Peacock Aari embroidery design' },
  { cat: 'Floral Aari Designs', src: 'images/floral-1.jpg', alt: 'Floral Aari embroidery design' },
  { cat: 'Temple Jewellery Designs', src: 'images/temple-1.jpg', alt: 'Temple jewellery Aari design' },
  { cat: 'Zardosi Work', src: 'images/zardosi-1.jpg', alt: 'Zardosi work blouse' },
  { cat: 'Designer Blouse Collections', src: 'images/designer-1.jpg', alt: 'Designer blouse collection' },
  { cat: 'Traditional Aari Embroidery', src: 'images/traditional-1.jpg', alt: 'Traditional Aari embroidery' },
];
